//
//  Weather.swift
//  Clima
//
//  Created by Abdur Razaq Nawfal on 26/11/20.
//  Copyright © 2020 App Brewery. All rights reserved.
//

import Foundation
